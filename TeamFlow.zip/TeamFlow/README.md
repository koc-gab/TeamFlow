# TeamFlow

Reszponzív, magyar nyelvű csapatmunka- és projektkezelő alkalmazás Angular 20.3-mal, Tailwind CSS-sel és JSON Server backenddel.

## Indítás

Node.js 20.19+ (vagy 22.12+) és npm szükséges. A két szervert külön terminálban indítsd:

```powershell
# 1. terminál — backend
cd server
npm install
npm start
```

```powershell
# 2. terminál — frontend (a projekt gyökérmappájából)
npm install
npm start
```

- Frontend: <http://localhost:4200>
- JSON Server API: <http://localhost:3000>

A frontend a `http://localhost:3000` végpontot használja. Az adatbázis módosításai a `server/db.json` fájlba kerülnek. Az eredeti kezdőadatok visszaállítása előtt mentsd el az aktuális adatbázist, majd futtasd:

```powershell
cd server
npm run reset
```

## Funkciók

- Dashboard projekt- és feladatstatisztikákkal, előrehaladással és közelgő határidőkkel.
- Feladatok keresése (debounce), szűrése projekt és állapot szerint, valamint rendezése.
- Projektek és projekt-tagok, csapattagok, címkék, állapotok és prioritások kezelése.
- Feladat létrehozása, szerkesztése, törlése; részletek, kommentek, időnapló és ellenőrzőlista.
- Kapcsolódó rekordok védelme törléskor, megerősítő párbeszédablakokkal.
- Reszponzív navigáció, mobilos feladatkártyák, billentyűzetes fókuszjelzés és űrlapvalidáció.

## CRUD-adatok és végpontok

| Adattípus | JSON Server útvonal |
| --- | --- |
| Users | `/users` |
| Projects | `/projects` |
| Tasks | `/tasks` |
| Comments | `/comments` |
| Labels | `/labels` |
| Statuses | `/statuses` |
| Priorities | `/priorities` |
| TimeEntries | `/timeEntries` |
| ChecklistItems | `/checklistItems` |
| ProjectMembers | `/projectMembers` |

Mind a tíz adattípus külön, típusos Angular service-t használ `HttpClient`-tel.

## Projektstruktúra

```text
src/app/
  app.routes.ts          Útvonalak
  app.config.ts          Router és HttpClient konfiguráció
  data.services.ts       Tíz JSON Server CRUD service
  models.ts              Adatmodellek
  task-search.ts         Debounce-os keresés és kombinált szűrés
  validators.ts          Űrlapvalidációs segédfüggvények
  workspace.ts/html      Alkalmazásnézet és műveletek
server/
  db.json                Aktuális adatbázis
  db.seed.json           Visszaállítható kezdőadatok
  reset.cjs              Adatbázis-visszaállító parancs
```

## Fejlesztés és tesztelés

```powershell
npm run build
npm test -- --watch=false
```

Lásd a [tesztjelentést](./docs/test-report.md) és a [közreműködési naplót](./docs/contributions.md).
