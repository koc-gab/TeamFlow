const { copyFileSync } = require('node:fs');
const { join } = require('node:path');

const directory = __dirname;
copyFileSync(join(directory, 'db.seed.json'), join(directory, 'db.json'));
console.log('TeamFlow database restored from db.seed.json.');
