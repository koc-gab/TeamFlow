import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import {
  CommentService,
  ProjectService,
  TaskService,
  UserService,
} from './data.services';

describe('JSON Server services', () => {
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('reads tasks from the tasks endpoint', () => {
    TestBed.inject(TaskService).getAll().subscribe((tasks) => expect(tasks).toEqual([]));
    http.expectOne('http://localhost:3000/tasks').flush([]);
  });

  it('creates a project with a JSON POST request', () => {
    const project = {
      name: 'Research',
      description: '',
      ownerId: 1,
      status: 'active',
      startDate: '2026-11-18',
      dueDate: '2026-12-01',
    };
    TestBed.inject(ProjectService).create(project).subscribe((saved) => expect(saved.id).toBe(3));
    const request = http.expectOne('http://localhost:3000/projects');
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual(project);
    request.flush({ id: 3, ...project });
  });

  it('updates users with PATCH', () => {
    TestBed.inject(UserService).update(2, { active: false }).subscribe((saved) => expect(saved.active).toBe(false));
    const request = http.expectOne('http://localhost:3000/users/2');
    expect(request.request.method).toBe('PATCH');
    expect(request.request.body).toEqual({ active: false });
    request.flush({ id: 2, name: 'Nagy Bence', email: 'bence@example.com', role: 'Developer', active: false });
  });

  it('deletes comments from the comments endpoint', () => {
    TestBed.inject(CommentService).delete(4).subscribe();
    const request = http.expectOne('http://localhost:3000/comments/4');
    expect(request.request.method).toBe('DELETE');
    request.flush(null);
  });
});
