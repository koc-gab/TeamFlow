import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject, tap } from 'rxjs';
import {
  ChecklistItem,
  Comment,
  Label,
  Priority,
  Project,
  ProjectMember,
  Status,
  Task,
  TimeEntry,
  User,
} from './models';

const API_URL = 'http://localhost:3000';

class JsonResource<T extends { id?: number }> {
  readonly changed = new Subject<void>();

  constructor(
    private readonly http: HttpClient,
    private readonly endpoint: string,
  ) {}

  getAll(): Observable<T[]> {
    return this.http.get<T[]>(`${API_URL}/${this.endpoint}`);
  }

  get(id: number): Observable<T> {
    return this.http.get<T>(`${API_URL}/${this.endpoint}/${id}`);
  }

  create(value: Omit<T, 'id'>): Observable<T> {
    return this.http
      .post<T>(`${API_URL}/${this.endpoint}`, value)
      .pipe(tap(() => this.changed.next()));
  }

  update(id: number, value: Partial<T>): Observable<T> {
    return this.http
      .patch<T>(`${API_URL}/${this.endpoint}/${id}`, value)
      .pipe(tap(() => this.changed.next()));
  }

  delete(id: number): Observable<void> {
    return this.http
      .delete<void>(`${API_URL}/${this.endpoint}/${id}`)
      .pipe(tap(() => this.changed.next()));
  }
}

@Injectable({ providedIn: 'root' })
export class UserService extends JsonResource<User> {
  constructor(http: HttpClient) {
    super(http, 'users');
  }
}

@Injectable({ providedIn: 'root' })
export class ProjectService extends JsonResource<Project> {
  constructor(http: HttpClient) {
    super(http, 'projects');
  }
}

@Injectable({ providedIn: 'root' })
export class TaskService extends JsonResource<Task> {
  constructor(http: HttpClient) {
    super(http, 'tasks');
  }
}

@Injectable({ providedIn: 'root' })
export class CommentService extends JsonResource<Comment> {
  constructor(http: HttpClient) {
    super(http, 'comments');
  }
}

@Injectable({ providedIn: 'root' })
export class LabelService extends JsonResource<Label> {
  constructor(http: HttpClient) {
    super(http, 'labels');
  }
}

@Injectable({ providedIn: 'root' })
export class StatusService extends JsonResource<Status> {
  constructor(http: HttpClient) {
    super(http, 'statuses');
  }
}

@Injectable({ providedIn: 'root' })
export class PriorityService extends JsonResource<Priority> {
  constructor(http: HttpClient) {
    super(http, 'priorities');
  }
}

@Injectable({ providedIn: 'root' })
export class TimeEntryService extends JsonResource<TimeEntry> {
  constructor(http: HttpClient) {
    super(http, 'timeEntries');
  }
}

@Injectable({ providedIn: 'root' })
export class ChecklistItemService extends JsonResource<ChecklistItem> {
  constructor(http: HttpClient) {
    super(http, 'checklistItems');
  }
}

@Injectable({ providedIn: 'root' })
export class ProjectMemberService extends JsonResource<ProjectMember> {
  constructor(http: HttpClient) {
    super(http, 'projectMembers');
  }
}
