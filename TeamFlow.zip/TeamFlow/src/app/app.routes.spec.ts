import { routes } from './app.routes';

describe('application routes', () => {
  it('provides task, project, team, settings, and fallback routes', () => {
    const paths = routes.map((route) => route.path);
    expect(paths).toEqual(expect.arrayContaining([
      'tasks',
      'tasks/new',
      'tasks/:id',
      'projects',
      'team',
      'settings',
      '**',
    ]));
  });
});
