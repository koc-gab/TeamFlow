import type { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export const trimmedTextValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null =>
  String(control.value ?? '').trim() ? null : { trimmed: true };

export function validDateRange(startDate: string, dueDate: string): boolean {
  return Boolean(startDate && dueDate && dueDate >= startDate);
}
