import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
  Component,
  DestroyRef,
  OnInit,
  inject,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  FormBuilder,
  FormControl,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { NavigationEnd, Router, RouterLink, RouterLinkActive } from '@angular/router';
import {
  Observable,
  BehaviorSubject,
  catchError,
  finalize,
  forkJoin,
  merge,
  of,
  tap,
  map,
} from 'rxjs';
import type {
  ChecklistItem,
  Comment,
  Id,
  Label,
  Priority,
  Project,
  ProjectMember,
  Status,
  Task,
  TimeEntry,
  User,
  WorkspaceData,
} from './models';
import {
  ChecklistItemService,
  CommentService,
  LabelService,
  PriorityService,
  ProjectMemberService,
  ProjectService,
  StatusService,
  TaskService,
  TimeEntryService,
  UserService,
} from './data.services';
import { taskSearchStream } from './task-search';
import { trimmedTextValidator, validDateRange } from './validators';
import { Overview } from './overview/overview';
import { Tasks } from './tasks/tasks';
import { Projects } from './projects/projects';
import { Team } from './team/team';
import { Settings } from './settings/settings';

type Page = 'dashboard' | 'tasks' | 'task-form' | 'task-detail' | 'projects' | 'project-detail' | 'project-form' | 'team' | 'settings' | 'not-found';
type CatalogType = 'labels' | 'statuses' | 'priorities';
type ModalType = 'comment' | 'time' | 'checklist' | 'member' | 'user' | CatalogType;
type DashboardStats = { total: number; active: number; completed: number; overdue: number; hours: number; progress: number };

const emptyData: WorkspaceData = {
  users: [],
  projects: [],
  tasks: [],
  comments: [],
  labels: [],
  statuses: [],
  priorities: [],
  timeEntries: [],
  checklistItems: [],
  projectMembers: [],
};

@Component({
  selector: 'app-workspace',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, RouterLinkActive, Overview, Tasks, Projects, Team, Settings],
  templateUrl: './workspace.html',
})
export class Workspace implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly router = inject(Router);
  private readonly destroyRef = inject(DestroyRef);
  private readonly usersApi = inject(UserService);
  private readonly projectsApi = inject(ProjectService);
  private readonly tasksApi = inject(TaskService);
  private readonly commentsApi = inject(CommentService);
  private readonly labelsApi = inject(LabelService);
  private readonly statusesApi = inject(StatusService);
  private readonly prioritiesApi = inject(PriorityService);
  private readonly timeApi = inject(TimeEntryService);
  private readonly checklistApi = inject(ChecklistItemService);
  private readonly membersApi = inject(ProjectMemberService);
  private readonly taskRows = new BehaviorSubject<Task[]>([]);

  data: WorkspaceData = emptyData;
  stats: DashboardStats = { total: 0, active: 0, completed: 0, overdue: 0, hours: 0, progress: 0 };
  filteredTasks$!: Observable<Task[]>;
  page: Page = 'dashboard';
  pageTitle = 'Dashboard';
  pageSubtitle = 'A projektjeid és a napi teendőid egy helyen.';
  selectedTask?: Task;
  selectedProject?: Project;
  editingTaskId?: Id;
  editingProjectId?: Id;
  editingUserId?: Id;
  editingCatalogId?: Id;
  editingModalId?: Id;
  modalType?: ModalType;
  modalTitle = '';
  loading = true;
  saving = false;
  mobileNavOpen = false;
  toast = '';
  errorMessage = '';
  sortBy = 'dueDate';
  readonly search = new FormControl('', { nonNullable: true });
  readonly statusFilter = new FormControl('', { nonNullable: true });
  readonly projectFilter = new FormControl('', { nonNullable: true });
  readonly taskForm = this.fb.group({
    title: this.fb.nonNullable.control('', { validators: [Validators.required, trimmedTextValidator, Validators.minLength(3), Validators.maxLength(80)] }),
    description: this.fb.nonNullable.control('', Validators.maxLength(1000)),
    projectId: this.fb.control<number | null>(null, Validators.required),
    assigneeId: this.fb.control<number | null>(null, Validators.required),
    statusId: this.fb.control<number | null>(null, Validators.required),
    priorityId: this.fb.control<number | null>(null, Validators.required),
    dueDate: this.fb.nonNullable.control('', Validators.required),
    estimateHours: this.fb.nonNullable.control(1, [Validators.required, Validators.min(0.5), Validators.max(100)]),
    labelIds: this.fb.nonNullable.control<number[]>([]),
  });
  readonly projectForm = this.fb.group({
    name: this.fb.nonNullable.control('', { validators: [Validators.required, trimmedTextValidator, Validators.minLength(3), Validators.maxLength(80)] }),
    description: this.fb.nonNullable.control('', Validators.maxLength(1000)),
    ownerId: this.fb.control<number | null>(null, Validators.required),
    startDate: this.fb.nonNullable.control('', Validators.required),
    dueDate: this.fb.nonNullable.control('', Validators.required),
  });
  readonly modalForm = this.fb.group({
    text: this.fb.nonNullable.control('', { validators: [Validators.required, trimmedTextValidator, Validators.maxLength(500)] }),
    note: this.fb.nonNullable.control('', Validators.maxLength(300)),
    minutes: this.fb.nonNullable.control(30, [Validators.required, Validators.min(1), Validators.max(1440)]),
    date: this.fb.nonNullable.control(new Date().toISOString().slice(0, 10)),
    userId: this.fb.control<number | null>(null),
    role: this.fb.nonNullable.control(''),
    color: this.fb.nonNullable.control('#315CE8'),
    key: this.fb.nonNullable.control('todo'),
    level: this.fb.nonNullable.control(2),
    order: this.fb.nonNullable.control(1),
    email: this.fb.nonNullable.control('', Validators.email),
    active: this.fb.nonNullable.control(true),
  });

  ngOnInit(): void {
    this.filteredTasks$ = taskSearchStream(
      this.taskRows,
      this.search.valueChanges,
      this.statusFilter.valueChanges,
      this.projectFilter.valueChanges,
      () => this.sortBy,
    );
    this.router.events
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((event) => {
        if (event instanceof NavigationEnd) {
          this.readRoute();
          this.mobileNavOpen = false;
        }

      });
    merge(
      this.usersApi.changed,
      this.projectsApi.changed,
      this.tasksApi.changed,
      this.commentsApi.changed,
      this.labelsApi.changed,
      this.statusesApi.changed,
      this.prioritiesApi.changed,
      this.timeApi.changed,
      this.checklistApi.changed,
      this.membersApi.changed,
    )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.loadData());
    this.loadData();
    this.readRoute();
  }

  trackById(_index: number, item: { id: Id }): Id {
    return item.id;
  }

  private readRoute(): void {
    const url = this.router.url.split('?')[0];
    const parts = url.split('/').filter(Boolean);
    this.errorMessage = '';
    this.selectedTask = undefined;
    this.selectedProject = undefined;

    if (!parts.length) {
      this.page = 'dashboard';
      this.pageTitle = 'Dashboard';
      this.pageSubtitle = 'A projektjeid és a napi teendőid egy helyen.';
    } else if (parts[0] === 'tasks' && parts[1] === 'new') {
      this.page = 'task-form';
      this.pageTitle = 'Új feladat';
      this.pageSubtitle = 'Töltsd ki a részleteket, és rendeld hozzá a csapatodhoz.';
      this.editingTaskId = undefined;
      this.taskForm.reset({ title: '', description: '', projectId: null, assigneeId: null, statusId: null, priorityId: null, dueDate: '', estimateHours: 1, labelIds: [] });
    } else if (parts[0] === 'tasks' && parts[2] === 'edit') {
      const task = this.data.tasks.find((item) => item.id === Number(parts[1]));
      this.page = task ? 'task-form' : 'not-found';
      this.pageTitle = task ? 'Feladat szerkesztése' : 'Az oldal nem található';
      this.pageSubtitle = task?.title ?? 'A keresett feladat nem létezik.';
      if (task) this.prepareTaskForm(task);
    } else if (parts[0] === 'tasks' && parts[1]) {
      this.selectedTask = this.data.tasks.find((item) => item.id === Number(parts[1]));
      this.page = this.selectedTask ? 'task-detail' : 'not-found';
      this.pageTitle = this.selectedTask?.title ?? 'Az oldal nem található';
      this.pageSubtitle = this.selectedTask?.description || 'A keresett feladat nem létezik.';
    } else if (parts[0] === 'tasks') {
      this.page = 'tasks';
      this.pageTitle = 'Feladatok';
      this.pageSubtitle = 'Kövesd nyomon, szűrd és rendezd a csapat teendőit.';
    } else if (parts[0] === 'projects' && parts[1] === 'new') {
      this.page = 'project-form';
      this.pageTitle = 'Új projekt';
      this.pageSubtitle = 'Hozz létre egy új munkaterületet a csapatodnak.';
      this.editingProjectId = undefined;
      this.projectForm.reset({ name: '', description: '', ownerId: this.data.users[0]?.id ?? null, startDate: new Date().toISOString().slice(0, 10), dueDate: '' });
    } else if (parts[0] === 'projects' && parts[2] === 'edit') {
      const project = this.data.projects.find((item) => item.id === Number(parts[1]));
      this.page = project ? 'project-form' : 'not-found';
      this.pageTitle = project ? 'Projekt szerkesztése' : 'Az oldal nem található';
      this.pageSubtitle = project?.name ?? 'A keresett projekt nem létezik.';
      if (project) {
        this.editingProjectId = project.id;
        this.projectForm.reset({
          name: project.name,
          description: project.description,
          ownerId: project.ownerId,
          startDate: project.startDate,
          dueDate: project.dueDate,
        });
      }
    } else if (parts[0] === 'projects' && parts[1]) {
      this.selectedProject = this.data.projects.find((item) => item.id === Number(parts[1]));
      this.page = this.selectedProject ? 'project-detail' : 'not-found';
      this.pageTitle = this.selectedProject?.name ?? 'Az oldal nem található';
      this.pageSubtitle = this.selectedProject?.description || 'A keresett projekt nem létezik.';
    } else if (parts[0] === 'projects') {
      this.page = 'projects';
      this.pageTitle = 'Projektek';
      this.pageSubtitle = 'A munkaterületek és a hozzájuk tartozó feladatok.';
    } else if (parts[0] === 'team') {
      this.page = 'team';
      this.pageTitle = 'Csapat';
      this.pageSubtitle = 'A munkatársak és a hozzájuk rendelt feladatok.';
    } else if (parts[0] === 'settings') {
      this.page = 'settings';
      this.pageTitle = 'Törzsadatok';
      this.pageSubtitle = 'A feladatokhoz használható állapotok, prioritások és címkék.';
    } else {
      this.page = 'not-found';
      this.pageTitle = 'Az oldal nem található';
      this.pageSubtitle = 'A kért oldal nem érhető el.';
    }
  }

  private loadData(): void {
    this.loading = true;
    this.errorMessage = '';
    forkJoin({
      users: this.usersApi.getAll(),
      projects: this.projectsApi.getAll(),
      tasks: this.tasksApi.getAll(),
      comments: this.commentsApi.getAll(),
      labels: this.labelsApi.getAll(),
      statuses: this.statusesApi.getAll(),
      priorities: this.prioritiesApi.getAll(),
      timeEntries: this.timeApi.getAll(),
      checklistItems: this.checklistApi.getAll(),
      projectMembers: this.membersApi.getAll(),
    }).pipe(
      map((data) => ({
        data,
        stats: this.dashboardStats(data.tasks, data.timeEntries, data.statuses),
      })),
    )
      .pipe(
        tap(({ data, stats }) => {
          this.data = data;
          this.taskRows.next(data.tasks);
          this.stats = stats;
          this.readRoute();
        }),
        catchError((error: HttpErrorResponse) => {
          this.errorMessage = error.status === 0
            ? 'Nem érhető el a JSON Server. Indítsd el a szervert a server mappából.'
            : `Az adatok betöltése nem sikerült (${error.status}).`;
          return of(null);
        }),
        finalize(() => (this.loading = false)),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe();
  }

  private dashboardStats(tasks: Task[], entries: TimeEntry[], statuses: Status[]): DashboardStats {
    const doneIds = new Set(statuses.filter((status) => status.key === 'done').map((status) => status.id));
    const now = new Date().toISOString().slice(0, 10);
    const nextWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    const completed = tasks.filter((task) => doneIds.has(task.statusId)).length;
    const active = tasks.length - completed;
    const hours = entries.reduce((sum, entry) => sum + entry.minutes, 0) / 60;
    return {
      total: tasks.length,
      active,
      completed,
      overdue: tasks.filter((task) => !doneIds.has(task.statusId) && task.dueDate >= now && task.dueDate <= nextWeek).length,
      hours,
      progress: tasks.length ? Math.round((completed / tasks.length) * 100) : 0,
    };
  }

  status(id: Id): Status | undefined {
    return this.data.statuses.find((item) => item.id === id);
  }

  priority(id: Id): Priority | undefined {
    return this.data.priorities.find((item) => item.id === id);
  }

  person(id: Id): User | undefined {
    return this.data.users.find((item) => item.id === id);
  }

  project(id: Id): Project | undefined {
    return this.data.projects.find((item) => item.id === id);
  }

  initials(name: string | undefined): string {
    return (name ?? '?').split(' ').map((part) => part[0] ?? '').slice(0, 2).join('').toUpperCase();
  }

  taskCount(projectId: Id): number {
    return this.data.tasks.filter((task) => task.projectId === projectId).length;
  }

  tasksForProject(projectId: Id): Task[] {
    return this.data.tasks.filter((task) => task.projectId === projectId);
  }

  commentsForTask(taskId: Id): Comment[] {
    return this.data.comments.filter((item) => item.taskId === taskId);
  }

  entriesForTask(taskId: Id): TimeEntry[] {
    return this.data.timeEntries.filter((item) => item.taskId === taskId);
  }

  checklistForTask(taskId: Id): ChecklistItem[] {
    return this.data.checklistItems.filter((item) => item.taskId === taskId);
  }

  membersForProject(projectId: Id): ProjectMember[] {
    return this.data.projectMembers.filter((item) => item.projectId === projectId);
  }

  labelsForTask(task: Task): Label[] {
    return this.data.labels.filter((item) => task.labelIds.includes(item.id));
  }

  projectProgress(projectId: Id): number {
    const tasks = this.tasksForProject(projectId);
    if (!tasks.length) return 0;
    const complete = tasks.filter((task) => this.status(task.statusId)?.key === 'done').length;
    return Math.round((complete / tasks.length) * 100);
  }

  completedChecklist(taskId: Id): number {
    return this.checklistForTask(taskId).filter((item) => item.done).length;
  }

  assignedTaskCount(userId: Id): number {
    return this.data.tasks.filter((task) => task.assigneeId === userId).length;
  }

  firstName(name: string | undefined): string {
    return name?.trim().split(/\s+/).slice(-1)[0] || 'csapat';
  }

  totalTrackedMinutes(taskId: Id): number {
    return this.entriesForTask(taskId).reduce((sum, entry) => sum + entry.minutes, 0);
  }

  changeSort(field: string): void {
    this.sortBy = field;
    this.taskRows.next(this.data.tasks);
  }

  private notify(message: string): void {
    this.toast = message;
    window.setTimeout(() => (this.toast = ''), 3000);
  }

  private reportMutationError(error: HttpErrorResponse): void {
    this.saving = false;
    this.errorMessage = error.status === 0 ? 'Nem érhető el a JSON Server.' : `A művelet nem sikerült (${error.status}).`;
  }

  openNewTask(): void {
    this.router.navigate(['/tasks/new']);
  }

  private prepareTaskForm(task: Task): void {
    if (this.editingTaskId === task.id && this.taskForm.dirty) return;
    this.editingTaskId = task.id;
    this.taskForm.reset({
      title: task.title,
      description: task.description,
      projectId: task.projectId,
      assigneeId: task.assigneeId,
      statusId: task.statusId,
      priorityId: task.priorityId,
      dueDate: task.dueDate,
      estimateHours: task.estimateHours,
      labelIds: task.labelIds,
    });
  }

  saveTask(): void {
    this.taskForm.markAllAsTouched();
    const value = this.taskForm.getRawValue();
    if (this.taskForm.invalid || !value.projectId || !value.assigneeId || !value.statusId || !value.priorityId) return;
    this.saving = true;
    this.errorMessage = '';
    const payload = {
      ...value,
      title: value.title.trim(),
      description: value.description.trim(),
      projectId: value.projectId,
      assigneeId: value.assigneeId,
      statusId: value.statusId,
      priorityId: value.priorityId,
      estimateHours: Number(value.estimateHours),
      labelIds: value.labelIds ?? [],
    };
    const request = this.editingTaskId
      ? this.tasksApi.update(this.editingTaskId, payload)
      : this.tasksApi.create(payload);
    request.pipe(
      finalize(() => (this.saving = false)),
      takeUntilDestroyed(this.destroyRef),
    ).subscribe({
      next: (task) => {
        this.notify(this.editingTaskId ? 'A feladat módosításai mentve.' : 'A feladat sikeresen létrejött.');
        this.router.navigate(['/tasks', task.id]);
      },
      error: (error: HttpErrorResponse) => this.reportMutationError(error),
    });
  }

  openProjectForm(project?: Project): void {
    if (project) {
      this.router.navigate(['/projects', project.id, 'edit']);
      return;
    }
    this.editingProjectId = project?.id;
    this.pageTitle = project ? 'Projekt szerkesztése' : 'Új projekt';
    this.projectForm.reset(project
      ? { name: project.name, description: project.description, ownerId: project.ownerId, startDate: project.startDate, dueDate: project.dueDate }
      : { name: '', description: '', ownerId: this.data.users[0]?.id ?? null, startDate: new Date().toISOString().slice(0, 10), dueDate: '' });
    this.modalType = undefined;
    this.page = 'project-form';
  }

  saveProject(): void {
    this.projectForm.markAllAsTouched();
    const value = this.projectForm.getRawValue();
    if (this.projectForm.invalid || !value.ownerId || !value.startDate || !value.dueDate) return;
    if (!validDateRange(value.startDate, value.dueDate)) {
      this.errorMessage = 'A határidő nem lehet korábbi a kezdődátumnál.';
      return;
    }
    this.saving = true;
    const payload = { ...value, name: value.name.trim(), description: value.description.trim(), ownerId: value.ownerId, status: 'active' };
    const request = this.editingProjectId
      ? this.projectsApi.update(this.editingProjectId, payload)
      : this.projectsApi.create(payload);
    request.pipe(finalize(() => (this.saving = false)), takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (project) => {
        this.notify(this.editingProjectId ? 'A projekt adatai frissültek.' : 'A projekt létrejött.');
        this.router.navigate(['/projects', project.id]);
      },
      error: (error: HttpErrorResponse) => this.reportMutationError(error),
    });
  }

  openUserForm(user?: User): void {
    this.editingUserId = user?.id;
    this.modalTitle = user ? 'Csapattag szerkesztése' : 'Új csapattag';
    this.modalType = 'user';
    this.modalForm.reset({ text: user?.name ?? '', email: user?.email ?? '', role: user?.role ?? '', active: user?.active ?? true });
  }

  saveUser(): void {
    const value = this.modalForm.getRawValue();
    const name = value.text.trim();
    const email = value.email.trim();
    const role = (value.role ?? '').trim();
    this.modalForm.controls.email.setValue(email);
    if (name.length < 2 || this.modalForm.controls.email.invalid || !role) {
      this.errorMessage = 'Adj meg egy legalább 2 karakteres nevet, érvényes e-mail-címet és szerepkört.';
      return;
    }
    if (this.data.users.some((user) => user.email.toLowerCase() === email.toLowerCase() && user.id !== this.editingUserId)) {
      this.errorMessage = 'Ezzel az e-mail-címmel már létezik csapattag.';
      return;
    }
    this.saving = true;
    const payload = { name, email, role, active: value.active ?? true };
    const request = this.editingUserId
      ? this.usersApi.update(this.editingUserId, payload)
      : this.usersApi.create(payload);
    request.pipe(finalize(() => (this.saving = false)), takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => { this.closeModal(); this.notify('A csapattag adatai mentve.'); },
      error: (error: HttpErrorResponse) => this.reportMutationError(error),
    });
  }

  openCatalogForm(type: CatalogType, item?: Label | Status | Priority): void {
    this.modalType = type;
    this.editingCatalogId = item?.id;
    this.modalTitle = item ? 'Törzsadat szerkesztése' : 'Új törzsadat';
    this.modalForm.reset({
      text: item?.name ?? '',
      color: (item as Label | Status | undefined)?.color ?? '#315CE8',
      key: (item as Status | undefined)?.key ?? 'todo',
      level: (item as Priority | undefined)?.level ?? 2,
      order: (item as Status | undefined)?.order ?? 1,
    });
  }

  saveCatalog(): void {
    const value = this.modalForm.getRawValue();
    const name = value.text.trim();
    if (name.length < 2) {
      this.errorMessage = 'A név legalább 2 karakter hosszú legyen.';
      return;
    }
    this.saving = true;
    let request: Observable<unknown>;
    if (this.modalType === 'labels') {
      const payload = { name, color: value.color ?? '#315CE8' };
      request = this.editingCatalogId ? this.labelsApi.update(this.editingCatalogId, payload) : this.labelsApi.create(payload);
    } else if (this.modalType === 'statuses') {
      const payload = { name, key: (value.key ?? 'todo').trim(), color: value.color ?? '#315CE8', order: Number(value.order) || 1 };
      request = this.editingCatalogId ? this.statusesApi.update(this.editingCatalogId, payload) : this.statusesApi.create(payload);
    } else {
      const payload = { name, level: Number(value.level) || 1 };
      request = this.editingCatalogId ? this.prioritiesApi.update(this.editingCatalogId, payload) : this.prioritiesApi.create(payload);
    }
    request.pipe(finalize(() => (this.saving = false)), takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => { this.closeModal(); this.notify('A törzsadat mentve.'); },
      error: (error: HttpErrorResponse) => this.reportMutationError(error),
    });
  }

  openModal(type: ModalType, title: string, itemId?: Id): void {
    this.modalType = type;
    this.modalTitle = title;
    this.editingModalId = itemId;
    this.errorMessage = '';
    const comment = this.data.comments.find((item) => item.id === itemId);
    const entry = this.data.timeEntries.find((item) => item.id === itemId);
    const checklist = this.data.checklistItems.find((item) => item.id === itemId);
    const member = this.data.projectMembers.find((item) => item.id === itemId);
    this.modalForm.reset({
      text: comment?.body ?? checklist?.text ?? '',
      note: entry?.note ?? '',
      minutes: entry?.minutes ?? 30,
      date: entry?.date ?? new Date().toISOString().slice(0, 10),
      userId: member?.userId ?? entry?.userId ?? this.data.users[0]?.id ?? null,
      role: member?.role ?? '',
      color: '#315CE8',
      key: 'todo',
      level: 2,
      order: 1,
      email: '',
      active: true,
    });
  }

  closeModal(): void {
    this.modalType = undefined;
    this.editingModalId = undefined;
    this.editingCatalogId = undefined;
    this.editingUserId = undefined;
    this.errorMessage = '';
  }

  saveModal(): void {
    const value = this.modalForm.getRawValue();
    const task = this.selectedTask;
    const project = this.selectedProject;
    if (this.modalType === 'user') { this.saveUser(); return; }
    if (this.modalType === 'labels' || this.modalType === 'statuses' || this.modalType === 'priorities') { this.saveCatalog(); return; }
    if (this.modalType === 'member' && project && value.userId) {
      if (this.data.projectMembers.some((item) => item.projectId === project.id && item.userId === value.userId && item.id !== this.editingModalId)) {
        this.errorMessage = 'Ez a felhasználó már tagja a projektnek.';
        return;
      }
      const payload = { projectId: project.id, userId: value.userId, role: (value.role ?? '').trim() || 'Csapattag' };
      const request = this.editingModalId
        ? this.membersApi.update(this.editingModalId, payload)
        : this.membersApi.create(payload);
      this.mutate(request, this.editingModalId ? 'A projekt-tagság frissítve.' : 'A projekt tagja hozzáadva.');
      return;
    }
    if (!task) return;
    const text = value.text.trim();
    if (this.modalType === 'comment' && text) {
      const request = this.editingModalId
        ? this.commentsApi.update(this.editingModalId, { body: text })
        : this.commentsApi.create({ taskId: task.id, userId: this.data.users[0]?.id ?? 1, body: text, createdAt: new Date().toISOString() });
      this.mutate(request, this.editingModalId ? 'A hozzászólás frissítve.' : 'A hozzászólás elküldve.');
    } else if (this.modalType === 'time' && Number(value.minutes) > 0) {
      const payload = { taskId: task.id, userId: value.userId ?? this.data.users[0]?.id ?? 1, minutes: Number(value.minutes), date: value.date || new Date().toISOString().slice(0, 10), note: (value.note ?? '').trim() };
      const request = this.editingModalId
        ? this.timeApi.update(this.editingModalId, payload)
        : this.timeApi.create(payload);
      this.mutate(request, this.editingModalId ? 'Az időbejegyzés frissítve.' : 'A munkaidő rögzítve.');
    } else if (this.modalType === 'checklist' && text) {
      const existing = this.data.checklistItems.find((item) => item.id === this.editingModalId);
      const request = existing
        ? this.checklistApi.update(existing.id, { text })
        : this.checklistApi.create({ taskId: task.id, text, done: false });
      this.mutate(request, existing ? 'Az ellenőrzőlista frissítve.' : 'Az ellenőrzőlista-elemet hozzáadtad.');
    } else {
      this.errorMessage = 'Töltsd ki a kötelező mezőt.';
    }
  }

  private mutate(request: Observable<unknown>, success: string): void {
    this.saving = true;
    request.pipe(finalize(() => (this.saving = false)), takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => { this.closeModal(); this.notify(success); },
      error: (error: HttpErrorResponse) => this.reportMutationError(error),
    });
  }

  toggleChecklist(item: ChecklistItem): void {
    this.checklistApi.update(item.id, { done: !item.done }).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => this.notify('Az ellenőrzőlista frissítve.'),
      error: (error: HttpErrorResponse) => this.reportMutationError(error),
    });
  }

  deleteTask(task: Task): void {
    const related = this.data.comments.some((item) => item.taskId === task.id)
      || this.data.timeEntries.some((item) => item.taskId === task.id)
      || this.data.checklistItems.some((item) => item.taskId === task.id);
    if (related) {
      this.errorMessage = 'A feladat nem törölhető: előbb töröld a hozzá tartozó kommenteket, időnaplókat és ellenőrzőlista-elemeket.';
      return;
    }
    if (!window.confirm(`Biztosan törlöd ezt a feladatot: „${task.title}”?`)) return;
    this.tasksApi.delete(task.id).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => { this.notify('A feladat törölve.'); this.router.navigate(['/tasks']); },
      error: (error: HttpErrorResponse) => this.reportMutationError(error),
    });
  }

  deleteProject(project: Project): void {
    if (this.data.tasks.some((task) => task.projectId === project.id) || this.data.projectMembers.some((item) => item.projectId === project.id)) {
      this.errorMessage = 'A projekt nem törölhető, amíg feladat vagy projekt-tag kapcsolódik hozzá.';
      return;
    }
    if (!window.confirm(`Biztosan törlöd ezt a projektet: „${project.name}”?`)) return;
    this.projectsApi.delete(project.id).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => { this.notify('A projekt törölve.'); this.router.navigate(['/projects']); },
      error: (error: HttpErrorResponse) => this.reportMutationError(error),
    });
  }

  deleteComment(item: Comment): void {
    if (!window.confirm('Biztosan törlöd ezt a hozzászólást?')) return;
    this.commentsApi.delete(item.id).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => this.notify('A hozzászólás törölve.'),
      error: (error: HttpErrorResponse) => this.reportMutationError(error),
    });
  }

  editComment(item: Comment): void {
    this.openModal('comment', 'Hozzászólás szerkesztése', item.id);
  }

  editTimeEntry(item: TimeEntry): void {
    this.openModal('time', 'Időbejegyzés szerkesztése', item.id);
  }

  editChecklist(item: ChecklistItem): void {
    this.openModal('checklist', 'Ellenőrzőlista szerkesztése', item.id);
  }

  editMember(item: ProjectMember): void {
    this.openModal('member', 'Projekt-tag szerkesztése', item.id);
  }

  deleteTimeEntry(item: TimeEntry): void {
    if (!window.confirm('Biztosan törlöd ezt az időbejegyzést?')) return;
    this.timeApi.delete(item.id).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => this.notify('Az időbejegyzés törölve.'),
      error: (error: HttpErrorResponse) => this.reportMutationError(error),
    });
  }

  deleteChecklist(item: ChecklistItem): void {
    if (!window.confirm('Biztosan törlöd ezt az ellenőrzőlista-elemet?')) return;
    this.checklistApi.delete(item.id).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => this.notify('Az ellenőrzőlista-elemet törölted.'),
      error: (error: HttpErrorResponse) => this.reportMutationError(error),
    });
  }

  deleteMember(item: ProjectMember): void {
    if (!window.confirm('Eltávolítod ezt a tagot a projektből?')) return;
    this.membersApi.delete(item.id).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => this.notify('A projekt-tag eltávolítva.'),
      error: (error: HttpErrorResponse) => this.reportMutationError(error),
    });
  }

  deleteCatalog(type: CatalogType, id: Id): void {
    if (!window.confirm('Biztosan törlöd ezt az elemet? A használt állapotok és prioritások nem törölhetők.')) return;
    let request: Observable<void>;
    if (type === 'labels') {
      if (this.data.tasks.some((task) => task.labelIds.includes(id))) {
        this.errorMessage = 'Ez a címke még feladathoz van rendelve.';
        return;
      }
      request = this.labelsApi.delete(id);
    } else if (type === 'statuses') {
      if (this.data.tasks.some((task) => task.statusId === id)) {
        this.errorMessage = 'Ez az állapot még feladathoz van rendelve.';
        return;
      }
      request = this.statusesApi.delete(id);
    } else {
      if (this.data.tasks.some((task) => task.priorityId === id)) {
        this.errorMessage = 'Ez a prioritás még feladathoz van rendelve.';
        return;
      }
      request = this.prioritiesApi.delete(id);
    }
    request.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => this.notify('Az elem törölve.'),
      error: (error: HttpErrorResponse) => this.reportMutationError(error),
    });
  }

  deleteUser(user: User): void {
    if (this.data.tasks.some((task) => task.assigneeId === user.id)
      || this.data.projects.some((item) => item.ownerId === user.id)
      || this.data.projectMembers.some((item) => item.userId === user.id)
      || this.data.comments.some((item) => item.userId === user.id)
      || this.data.timeEntries.some((item) => item.userId === user.id)) {
      this.errorMessage = 'A csapattag nem törölhető, mert projekthez vagy feladathoz kapcsolódik.';
      return;
    }
    if (!window.confirm(`Biztosan törlöd ${user.name} profilját?`)) return;
    this.usersApi.delete(user.id).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => this.notify('A csapattag törölve.'),
      error: (error: HttpErrorResponse) => this.reportMutationError(error),
    });
  }

  toggleLabel(labelId: Id, event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    const selected = this.taskForm.controls.labelIds.value;
    this.taskForm.controls.labelIds.setValue(
      checked ? [...selected, labelId] : selected.filter((id) => id !== labelId),
    );
  }
}
