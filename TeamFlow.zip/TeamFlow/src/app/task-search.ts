import {
  Observable,
  combineLatest,
  debounceTime,
  distinctUntilChanged,
  map,
  startWith,
  switchMap,
} from 'rxjs';
import type { Task } from './models';

export function taskSearchStream(
  tasks$: Observable<Task[]>,
  search$: Observable<string>,
  status$: Observable<string>,
  project$: Observable<string>,
  sortBy: () => string,
): Observable<Task[]> {
  const searchResults$ = search$.pipe(
    startWith(''),
    debounceTime(250),
    distinctUntilChanged(),
    switchMap((query) => tasks$.pipe(map((tasks) => ({ tasks, query })))),
  );

  return combineLatest([
    searchResults$,
    status$.pipe(startWith('')),
    project$.pipe(startWith('')),
  ]).pipe(
    map(([search, status, project]) => {
      const query = search.query.trim().toLocaleLowerCase();
      return search.tasks
        .filter((task) => !query || `${task.title} ${task.description}`.toLocaleLowerCase().includes(query))
        .filter((task) => !status || String(task.statusId) === status)
        .filter((task) => !project || String(task.projectId) === project)
        .sort((a, b) => String(a[sortBy() as keyof Task] ?? '').localeCompare(String(b[sortBy() as keyof Task] ?? '')));
    }),
  );
}
