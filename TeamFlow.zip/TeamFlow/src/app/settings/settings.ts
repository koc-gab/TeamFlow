import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import type { Workspace } from '../workspace';

@Component({
  selector: 'app-settings',
  imports: [CommonModule],
  templateUrl: './settings.html',
  styleUrl: './settings.css',
})
export class Settings {
  @Input() workspace?: Workspace;
}
