import { BehaviorSubject } from 'rxjs';
import { Task } from './models';
import { taskSearchStream } from './task-search';

const sampleTasks: Task[] = [
  { id: 1, title: 'API service layer', description: 'HTTP requests', projectId: 1, assigneeId: 1, statusId: 2, priorityId: 3, dueDate: '2026-12-01', estimateHours: 5, labelIds: [] },
  { id: 2, title: 'Responsive layout', description: 'Mobile cards', projectId: 2, assigneeId: 2, statusId: 1, priorityId: 2, dueDate: '2026-12-02', estimateHours: 4, labelIds: [] },
];

describe('task search stream', () => {
  it('debounces text search and combines status and project filters', async () => {
    const tasks = new BehaviorSubject(sampleTasks);
    const query = new BehaviorSubject('');
    const status = new BehaviorSubject('');
    const project = new BehaviorSubject('');
    let result: Task[] = [];
    const subscription = taskSearchStream(tasks, query, status, project, () => 'dueDate')
      .subscribe((value) => (result = value));
    const waitForDebounce = () => new Promise((resolve) => setTimeout(resolve, 275));

    await waitForDebounce();
    query.next('API');
    await waitForDebounce();
    expect(result.map((task) => task.id)).toEqual([1]);

    status.next('2');
    project.next('2');
    expect(result).toEqual([]);
    subscription.unsubscribe();
  });
});
