import { Routes } from '@angular/router';
import { Workspace } from './workspace';

export const routes: Routes = [
  { path: '', component: Workspace },
  { path: 'tasks', component: Workspace },
  { path: 'tasks/new', component: Workspace },
  { path: 'tasks/:id/edit', component: Workspace },
  { path: 'tasks/:id', component: Workspace },
  { path: 'projects', component: Workspace },
  { path: 'projects/new', component: Workspace },
  { path: 'projects/:id', component: Workspace },
  { path: 'team', component: Workspace },
  { path: 'settings', component: Workspace },
  { path: '**', component: Workspace },
];
