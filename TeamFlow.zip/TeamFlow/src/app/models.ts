export type Id = number;

export interface User {
  id: Id;
  name: string;
  email: string;
  role: string;
  active: boolean;
}

export interface Project {
  id: Id;
  name: string;
  description: string;
  ownerId: Id;
  status: string;
  startDate: string;
  dueDate: string;
}

export interface Task {
  id: Id;
  projectId: Id;
  title: string;
  description: string;
  assigneeId: Id;
  statusId: Id;
  priorityId: Id;
  dueDate: string;
  estimateHours: number;
  labelIds: Id[];
}

export interface Comment {
  id: Id;
  taskId: Id;
  userId: Id;
  body: string;
  createdAt: string;
}

export interface Label {
  id: Id;
  name: string;
  color: string;
}

export interface Status {
  id: Id;
  name: string;
  key: string;
  color: string;
  order: number;
}

export interface Priority {
  id: Id;
  name: string;
  level: number;
}

export interface TimeEntry {
  id: Id;
  taskId: Id;
  userId: Id;
  minutes: number;
  date: string;
  note: string;
}

export interface ChecklistItem {
  id: Id;
  taskId: Id;
  text: string;
  done: boolean;
}

export interface ProjectMember {
  id: Id;
  projectId: Id;
  userId: Id;
  role: string;
}

export interface WorkspaceData {
  users: User[];
  projects: Project[];
  tasks: Task[];
  comments: Comment[];
  labels: Label[];
  statuses: Status[];
  priorities: Priority[];
  timeEntries: TimeEntry[];
  checklistItems: ChecklistItem[];
  projectMembers: ProjectMember[];
}
