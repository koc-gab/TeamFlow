import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import type { Workspace } from '../workspace';

@Component({
  selector: 'app-team',
  imports: [CommonModule],
  templateUrl: './team.html',
  styleUrl: './team.css',
})
export class Team {
  @Input() workspace?: Workspace;
}
