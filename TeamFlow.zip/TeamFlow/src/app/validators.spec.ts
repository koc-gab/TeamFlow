import { FormControl, Validators } from '@angular/forms';
import { trimmedTextValidator, validDateRange } from './validators';

describe('form validation helpers', () => {
  it('rejects whitespace-only text and accepts trimmed content', () => {
    const control = new FormControl('   ', [Validators.required, trimmedTextValidator, Validators.minLength(3)]);
    expect(control.hasError('trimmed')).toBe(true);

    control.setValue(' API ');
    expect(control.valid).toBe(true);
  });

  it('requires a due date on or after the project start date', () => {
    expect(validDateRange('2026-11-20', '2026-11-19')).toBe(false);
    expect(validDateRange('2026-11-20', '2026-11-20')).toBe(true);
    expect(validDateRange('2026-11-20', '')).toBe(false);
  });
});
